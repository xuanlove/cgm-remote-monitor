<?php
declare(strict_types=1);

/**
 * The panel's public URL surface.
 *
 * Every path here existed before the refactor and must keep answering the same
 * way: the dashboard fetches /data/*.json every 30 s, bookmarks point at
 * /reports and /treatments, and the export links carry a .csv/.json suffix.
 */

use app\middleware\AdminOnly;
use app\middleware\ApiAuth;
use app\middleware\Authenticate;
use app\middleware\CsrfGuard;
use app\middleware\GuestOnly;
use app\middleware\Throttle;
use think\facade\Route;

Route::get('/', 'Index/index');
Route::get('login', 'Auth/loginPage')->middleware(GuestOnly::class);
Route::post('login', 'Auth/login')
    ->middleware(CsrfGuard::class)
    ->middleware(Throttle::class, 'login', 20, 900);
Route::get('register', 'Auth/registerPage');
Route::post('register', 'Auth/register')
    ->middleware(CsrfGuard::class)
    ->middleware(Throttle::class, 'register', 10, 3600);

// Any method so the controller can answer 405 + Allow: POST itself. The CSRF
// guard skips the GET probe and rejects token-less POSTs, so a cross-site
// form cannot sign the user out either.
Route::any('logout', 'Auth/logout')->middleware(CsrfGuard::class);
Route::post('lang', 'Lang/switchLang')->middleware(CsrfGuard::class);

Route::group(function () {
    Route::get('dashboard', 'Dashboard/index');

    Route::get('data/glucose', 'Data/glucose')->ext('json');
    Route::get('data/treatments', 'Data/treatments')->ext('json');
    Route::post('data/alerts/ack', 'Data/ackAlerts')->middleware(CsrfGuard::class, 'json');

    Route::get('settings/alerts', 'Settings/alerts');
    Route::post('settings/alerts', 'Settings/saveAlerts')->middleware(CsrfGuard::class);

    Route::get('profile', 'Profile/show');
    Route::post('profile', 'Profile/save')->middleware(CsrfGuard::class);

    Route::get('entry', 'Entry/show');
    Route::post('entry', 'Entry/submit')->middleware(CsrfGuard::class);

    Route::get('treatments', 'Treatment/index');
    Route::post('treatments/save', 'Treatment/save')->middleware(CsrfGuard::class);
    Route::post('treatments/delete', 'Treatment/delete')->middleware(CsrfGuard::class);

    Route::get('profile/plans', 'Plan/index');
    Route::post('profile/plans/activate', 'Plan/activate')->middleware(CsrfGuard::class);
    Route::post('profile/plans/delete', 'Plan/delete')->middleware(CsrfGuard::class);

    Route::get('reports', 'Report/index');

    // ThinkPHP strips the request extension before matching, so the rule
    // carries the bare path and `ext()` pins which suffix it answers to.
    Route::get('export/entries', 'Export/entriesCsv')->ext('csv');
    Route::get('export/entries', 'Export/entriesJson')->ext('json');
    Route::get('export/treatments', 'Export/treatmentsCsv')->ext('csv');

    Route::get('myapi', 'Api/index');

    Route::get('admin/users', 'Admin/users')->middleware(AdminOnly::class);
    Route::post('admin/users/delete', 'Admin/deleteUser')
        ->middleware(CsrfGuard::class)
        ->middleware(AdminOnly::class);

    Route::post('admin/backends/add', 'Admin/addBackend')
        ->middleware(CsrfGuard::class)
        ->middleware(AdminOnly::class);
    Route::post('admin/backends/save', 'Admin/saveBackend')
        ->middleware(CsrfGuard::class)
        ->middleware(AdminOnly::class);
    Route::post('admin/backends/toggle', 'Admin/toggleBackend')
        ->middleware(CsrfGuard::class)
        ->middleware(AdminOnly::class);
    Route::post('admin/backends/delete', 'Admin/deleteBackend')
        ->middleware(CsrfGuard::class)
        ->middleware(AdminOnly::class);
    Route::post('admin/backends/test', 'Admin/testBackend')
        ->middleware(CsrfGuard::class)
        ->middleware(AdminOnly::class);

    Route::get('admin/migrate', 'Admin/migratePage')->middleware(AdminOnly::class);
    Route::post('admin/migrate/confirm', 'Admin/migrateConfirm')
        ->middleware(CsrfGuard::class)
        ->middleware(AdminOnly::class);
    Route::post('admin/migrate/run', 'Admin/migrateRun')
        ->middleware(CsrfGuard::class)
        ->middleware(AdminOnly::class);
})->middleware(Authenticate::class);

// ------------------------------------------------------ NS-compatible API
// Nightscout-shaped reads from the local mirror: third-party tools point at
// the panel with the same api-secret token the backend would use. Throttle is
// declared before ApiAuth, so brute-forcing the token counts against the rate
// bucket and answers 429 instead of 401 forever. Each path exists with and
// without the .json suffix, exactly like the backend.
Route::group(function () {
    Route::get('api/v1/entries', 'NsApi/entries')->ext('json');
    Route::get('api/v1/entries', 'NsApi/entries');
    Route::get('api/v1/treatments', 'NsApi/treatments')->ext('json');
    Route::get('api/v1/treatments', 'NsApi/treatments');
    Route::get('api/v1/devicestatus', 'NsApi/devicestatus')->ext('json');
    Route::get('api/v1/devicestatus', 'NsApi/devicestatus');
    Route::get('api/v1/profile', 'NsApi/profile')->ext('json');
    Route::get('api/v1/profile', 'NsApi/profile');
    Route::get('api/v1/profile/current', 'NsApi/profileCurrent')->ext('json');
    Route::get('api/v1/profile/current', 'NsApi/profileCurrent');
    Route::get('api/v1/status', 'NsApi/status')->ext('json');
    Route::get('api/v1/status', 'NsApi/status');
})->middleware(Throttle::class, 'api', 120, 60, 'json')
  ->middleware(ApiAuth::class);

// Writes: same attribution rules as the backend applies for the caller's
// token (device / enteredBy = username). Token auth only — writes always
// need the api-secret header, exactly like they do against Nightscout.
Route::group(function () {
    Route::post('api/v1/entries', 'NsApi/postEntries')->ext('json');
    Route::post('api/v1/entries', 'NsApi/postEntries');
    Route::post('api/v1/treatments', 'NsApi/postTreatments')->ext('json');
    Route::post('api/v1/treatments', 'NsApi/postTreatments');
    Route::post('api/v1/devicestatus', 'NsApi/postDeviceStatus')->ext('json');
    Route::post('api/v1/devicestatus', 'NsApi/postDeviceStatus');
    Route::put('api/v1/profile', 'NsApi/putProfile')->ext('json');
    Route::put('api/v1/profile', 'NsApi/putProfile');
})->middleware(Throttle::class, 'api', 120, 60, 'json')
  ->middleware(ApiAuth::class, 'token');

Route::miss('Error/notFound');
