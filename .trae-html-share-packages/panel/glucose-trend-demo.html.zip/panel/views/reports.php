<?php
/** @var array $stats */
$hasData = ($stats['count'] ?? 0) > 0;
?>
<h1><?= t('rep.title') ?> <span class="hint" style="font-size:13px;">· <?= t('rep.subtitle', [
    'name' => htmlspecialchars($user['username']),
    'from' => htmlspecialchars($from),
    'to' => htmlspecialchars($to),
]) ?></span></h1>

<div class="card">
  <form method="get" action="/reports" style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;">
    <strong><?= t('rep.range') ?></strong>
    <?php foreach ([7, 14, 30, 90] as $option): ?>
      <a href="/reports?days=<?= $option ?>"
         style="padding:4px 12px;border-radius:6px;text-decoration:none;<?= $days === $option ? 'background:var(--accent);color:#fff;' : 'border:1px solid var(--line);' ?>">
        <?= t('rep.lastDays', ['n' => $option]) ?>
      </a>
    <?php endforeach; ?>
    <span class="hint"><?= t('rep.readings', ['n' => (int)$stats['count']]) ?><?php if ($stats['coverage'] !== null): ?> · <?= t('rep.coverage', ['n' => $stats['coverage']]) ?><?php endif; ?></span>
  </form>
  <div style="margin-top:10px;display:flex;gap:10px;flex-wrap:wrap;">
    <span class="hint"><?= t('rep.export') ?></span>
    <a href="/export/entries.csv?days=<?= $days ?>" class="hint"><?= t('rep.exportCsv') ?></a>
    <a href="/export/entries.json?days=<?= $days ?>" class="hint"><?= t('rep.exportJson') ?></a>
    <a href="/export/treatments.csv?days=<?= $days ?>" class="hint"><?= t('rep.exportTreatments') ?></a>
  </div>
</div>

<?php if (!$hasData): ?>
  <div class="card"><p class="hint"><?= t('rep.noData', ['name' => htmlspecialchars($user['username'])]) ?></p></div>
<?php else: ?>

<div class="card">
  <div class="grid" style="grid-template-columns:repeat(4,1fr);gap:14px;">
    <div>
      <div class="hint"><?= t('rep.tir') ?></div>
      <div style="font-size:26px;font-weight:600;color:#3fb27f;"><?= $stats['tir'] ?>%</div>
    </div>
    <div>
      <div class="hint"><?= t('rep.mean') ?></div>
      <div style="font-size:26px;font-weight:600;"><?= $stats['mean'] ?> <span style="font-size:14px;" class="hint">mmol/L</span></div>
    </div>
    <div>
      <div class="hint"><?= t('rep.gmi') ?></div>
      <div style="font-size:26px;font-weight:600;"><?= $stats['gmi'] ?? '-' ?><span style="font-size:14px;" class="hint">%</span></div>
    </div>
    <div>
      <div class="hint"><?= t('rep.cv') ?></div>
      <div style="font-size:26px;font-weight:600;"><?= $stats['cv'] ?? '-' ?><span style="font-size:14px;" class="hint">%</span></div>
    </div>
  </div>
  <div class="grid" style="grid-template-columns:repeat(4,1fr);gap:14px;margin-top:16px;">
    <div>
      <div class="hint"><?= t('rep.tbr') ?></div>
      <div style="font-size:18px;color:#e05a5a;"><?= $stats['tbr'] ?>%</div>
      <div class="hint"><?= t('rep.tbr2', ['n' => $stats['tbr2']]) ?></div>
    </div>
    <div>
      <div class="hint"><?= t('rep.tar') ?></div>
      <div style="font-size:18px;color:#e0a05a;"><?= $stats['tar'] ?>%</div>
      <div class="hint"><?= t('rep.tar2', ['n' => $stats['tar2']]) ?></div>
    </div>
    <div>
      <div class="hint"><?= t('rep.lowEvents') ?></div>
      <div style="font-size:18px;"><?= t('rep.lowEventsCount', ['n' => $stats['lowEvents']['events']]) ?></div>
      <div class="hint"><?= t('rep.lowEventsDetail', [
          'minutes' => $stats['lowEvents']['minutes'],
          'longest' => $stats['lowEvents']['longest'],
      ]) ?></div>
    </div>
    <div>
      <div class="hint"><?= t('rep.targetHit') ?></div>
      <div style="font-size:18px;"><?= $stats['target']['percent'] ?>%</div>
      <div class="hint"><?= t('rep.targetRange', [
          'low' => $stats['target']['low'],
          'high' => $stats['target']['high'],
      ]) ?></div>
    </div>
  </div>
</div>

<div class="card">
  <h1 style="font-size:16px;"><?= t('rep.distribution') ?></h1>
  <div id="distribution" style="width:100%;height:320px;"></div>
</div>

<div class="card">
  <h1 style="font-size:16px;"><?= t('rep.tirChart') ?></h1>
  <div id="tirChart" style="width:100%;height:320px;"></div>
  <p class="hint"><?= t('rep.thresholdsNote', [
      'median' => $stats['median'],
      'std' => $stats['std'],
      'min' => $stats['min'],
      'max' => $stats['max'],
  ]) ?></p>
</div>

<script src="/vendor/echarts.min.js"></script>
<script>
const STATS = <?= js_json($stats) ?>;
const I18N = <?= \NightPanel\Lang::js([
    'rep.share',
    'rep.percentage',
    'bucket.veryLow',
    'bucket.low',
    'bucket.inRange',
    'bucket.high',
    'bucket.veryHigh',
    'seg.below',
    'seg.inRange',
    'seg.above',
    'rep.lowEventsCount',
]) ?>;
const LOCALE = <?= js_json(\NightPanel\Lang::htmlLang()) ?>;

function themeColors () {
  const light = document.documentElement.classList.contains('light');
  return light
    ? { fg: '#1c2430', muted: '#5f6b7e', line: '#d8dee9' }
    : { fg: '#e6ebf4', muted: '#8b95a9', line: '#313a4d' };
}

const BUCKETS = [
  { key: 'veryLow',  label: I18N['bucket.veryLow'],  color: '#b53a3a' },
  { key: 'low',      label: I18N['bucket.low'],      color: '#e05a5a' },
  { key: 'inRange',  label: I18N['bucket.inRange'],  color: '#3fb27f' },
  { key: 'high',     label: I18N['bucket.high'],     color: '#e0a05a' },
  { key: 'veryHigh', label: I18N['bucket.veryHigh'], color: '#c07d2a' }
];

const distribution = echarts.init(document.getElementById('distribution'));
const tirChart = echarts.init(document.getElementById('tirChart'));
window.addEventListener('resize', () => { distribution.resize(); tirChart.resize(); });

function render () {
  const c = themeColors();
  const base = {
    backgroundColor: 'transparent',
    textStyle: { color: c.muted },
    grid: { left: 56, right: 24, top: 30, bottom: 40 }
  };

  distribution.setOption(Object.assign({}, base, {
    tooltip: {
      trigger: 'axis',
      axisPointer: { type: 'shadow' },
      formatter: p => {
        const i = p[0].dataIndex;
        return '<b>' + BUCKETS[i].label + '</b><br/>' + I18N['rep.share'].replace(':n', STATS.percent[BUCKETS[i].key]);
      }
    },
    xAxis: {
      type: 'category',
      data: BUCKETS.map(b => b.label),
      axisLine: { lineStyle: { color: c.line } },
      axisTick: { show: false },
      axisLabel: { color: c.muted, interval: 0, fontSize: 11 }
    },
    yAxis: {
      type: 'value',
      name: '%',
      max: 100,
      axisLine: { show: false },
      axisLabel: { color: c.muted },
      splitLine: { lineStyle: { color: c.line, opacity: .45 } }
    },
    series: [{
      type: 'bar',
      barMaxWidth: 64,
      data: BUCKETS.map(b => ({ value: STATS.percent[b.key], itemStyle: { color: b.color, borderRadius: [4, 4, 0, 0] } })),
      label: { show: true, position: 'top', formatter: '{c}%', color: c.fg, fontSize: 12 }
    }]
  }), true);

  const segments = [
    { name: I18N['seg.below'], value: STATS.tbr, color: '#e05a5a' },
    { name: I18N['seg.inRange'], value: STATS.tir, color: '#3fb27f' },
    { name: I18N['seg.above'], value: STATS.tar, color: '#e0a05a' }
  ];

  tirChart.setOption({
    backgroundColor: 'transparent',
    textStyle: { color: c.muted },
    tooltip: { trigger: 'item', formatter: '{b}: {c}%' },
    legend: { bottom: 0, textStyle: { color: c.fg } },
    series: [{
      type: 'pie',
      radius: ['48%', '72%'],
      center: ['50%', '45%'],
      avoidLabelOverlap: true,
      itemStyle: { borderColor: 'transparent', borderWidth: 2 },
      label: { show: true, formatter: '{b}\n{c}%', color: c.fg, fontSize: 12 },
      data: segments.map(s => ({ name: s.name, value: s.value, itemStyle: { color: s.color } }))
    }]
  }, true);
}

render();
new MutationObserver(render).observe(document.documentElement, { attributes: true, attributeFilter: ['class'] });
</script>

<?php endif; ?>
