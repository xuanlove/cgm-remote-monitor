<h1><?= t('al.title') ?> <span class="hint" style="font-size:13px;">· <?= t('al.subtitle') ?></span></h1>

<?php if (!empty($error)): ?><p class="msg-bad"><?= htmlspecialchars($error) ?></p><?php endif; ?>
<?php if (!empty($success)): ?><p class="msg-ok"><?= htmlspecialchars($success) ?></p><?php endif; ?>

<div class="card" style="max-width:560px;">
  <form method="post" action="/settings/alerts">
    <input type="hidden" name="csrf" value="<?= htmlspecialchars(\NightPanel\Auth::csrfToken()) ?>">

    <label style="display:flex;gap:8px;align-items:center;">
      <input type="checkbox" name="enabled" value="1" style="width:auto;" <?= $settings['enabled'] ? 'checked' : '' ?>>
      <?= t('al.enable') ?>
    </label>

    <div class="grid">
      <div>
        <label><?= t('al.lowLabel') ?></label>
        <input name="low" type="number" step="0.1" min="2" max="10" value="<?= htmlspecialchars((string)$settings['low']) ?>" required>
        <span class="hint"><?= t('al.lowRange') ?></span>
      </div>
      <div>
        <label><?= t('al.highLabel') ?></label>
        <input name="high" type="number" step="0.1" min="5" max="25" value="<?= htmlspecialchars((string)$settings['high']) ?>" required>
        <span class="hint"><?= t('al.highRange') ?></span>
      </div>
    </div>

    <label style="display:flex;gap:8px;align-items:center;margin-top:14px;">
      <input type="checkbox" name="browser" value="1" style="width:auto;" <?= $settings['browser'] ? 'checked' : '' ?>>
      <?= t('al.browser') ?>
    </label>

    <button><?= t('al.save') ?></button>
    <a href="/dashboard" style="margin-left:12px;"><?= t('al.back') ?></a>
  </form>

  <div style="margin-top:16px;">
    <button type="button" onclick="askPermission()" style="background:transparent;border:1px solid var(--line);color:var(--fg);">
      <?= t('al.grant') ?>
    </button>
    <span id="permState" class="hint"></span>
  </div>
</div>

<div class="card" style="max-width:560px;">
  <h1 style="font-size:15px;"><?= t('al.notesTitle') ?></h1>
  <ul class="hint" style="margin:0;padding-left:18px;">
    <li><?= t('al.note1') ?></li>
    <li><?= t('al.note2') ?></li>
    <li><?= t('al.note3') ?></li>
  </ul>
</div>

<script>
const PERM_TEXT = <?= \NightPanel\Lang::js(['al.perm.unsupported', 'al.perm.granted', 'al.perm.denied', 'al.perm.default']) ?>;

function paintPermission () {
  const el = document.getElementById('permState');
  if (typeof Notification === 'undefined') {
    el.textContent = PERM_TEXT['al.perm.unsupported'];
    return;
  }
  const map = {
    granted: PERM_TEXT['al.perm.granted'],
    denied: PERM_TEXT['al.perm.denied'],
    default: PERM_TEXT['al.perm.default']
  };
  el.textContent = map[Notification.permission] || Notification.permission;
  el.className = Notification.permission === 'granted' ? 'msg-ok' : 'hint';
}

function askPermission () {
  if (typeof Notification === 'undefined') return;
  Notification.requestPermission().then(paintPermission);
}

paintPermission();
</script>
